package com.misfit.opnmart.utility

class Keyword {
    companion object {
        const val CARTPAGE = "CHECKOUT"
        const val SCREEN_WIDTH = "width"
        const val SCREEN_HEIGHT = "height"
        const val SCREEN_DENSITY = "density"

    }

}