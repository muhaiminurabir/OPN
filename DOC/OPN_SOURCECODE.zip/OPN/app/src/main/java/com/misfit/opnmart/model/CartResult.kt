package com.misfit.opnmart.model

data class CartResult(val loading: Boolean, val sucess: Boolean)