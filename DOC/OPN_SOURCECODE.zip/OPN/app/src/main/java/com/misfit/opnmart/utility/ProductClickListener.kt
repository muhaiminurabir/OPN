package com.misfit.opnmart.utility

import com.misfit.opnmart.model.Productdatum

interface ProductClickListener {
    fun onproductClickListener(data: Productdatum)
}